KELOMPOK 4:
Wilda Meroca Aurora (3123521035)
Muhammad Abi Dafa Afandi (3123521048)

Link Figma:https://www.figma.com/design/ZEvRBlSbWguGsEsCKd9PPu/Senior-Living?node-id=0-1&p=f&t=ANcJpgGzKKHfC3Og-0
