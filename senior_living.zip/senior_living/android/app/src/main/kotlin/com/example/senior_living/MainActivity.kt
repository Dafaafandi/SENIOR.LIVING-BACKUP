package com.example.senior_living

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
